﻿namespace LMS
{
    partial class dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(dashboard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.delete_book = new System.Windows.Forms.Button();
            this.update_book = new System.Windows.Forms.Button();
            this.view_books = new System.Windows.Forms.Button();
            this.add_book = new System.Windows.Forms.Button();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.button1 = new System.Windows.Forms.Button();
            this.search_btn = new System.Windows.Forms.Button();
            this.search_book = new System.Windows.Forms.TextBox();
            this.tabs = new System.Windows.Forms.Panel();
            this.view_page = new LMS.viewBooks();
            this.add_page = new LMS.UC_Addbook();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tabs.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Black;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(815, 53);
            this.panel1.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Showcard Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(270, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(297, 23);
            this.label3.TabIndex = 2;
            this.label3.Text = "Library Management System";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(41, 23);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Admin";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(41, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Talib Raath";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(0, 0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(35, 36);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Black;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(783, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 29);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel2.Controls.Add(this.delete_book);
            this.panel2.Controls.Add(this.update_book);
            this.panel2.Controls.Add(this.view_books);
            this.panel2.Controls.Add(this.add_book);
            this.panel2.Controls.Add(this.pictureBox3);
            this.panel2.Location = new System.Drawing.Point(0, 53);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(194, 492);
            this.panel2.TabIndex = 1;
            // 
            // delete_book
            // 
            this.delete_book.FlatAppearance.BorderSize = 0;
            this.delete_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.delete_book.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.delete_book.ForeColor = System.Drawing.Color.White;
            this.delete_book.Image = ((System.Drawing.Image)(resources.GetObject("delete_book.Image")));
            this.delete_book.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.delete_book.Location = new System.Drawing.Point(3, 364);
            this.delete_book.Name = "delete_book";
            this.delete_book.Size = new System.Drawing.Size(188, 58);
            this.delete_book.TabIndex = 5;
            this.delete_book.Text = "Delete Book";
            this.delete_book.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.delete_book.UseVisualStyleBackColor = true;
            this.delete_book.Click += new System.EventHandler(this.button3_Click);
            this.delete_book.MouseLeave += new System.EventHandler(this.delete_mouse_keave_hover);
            this.delete_book.MouseHover += new System.EventHandler(this.delete_mouse_hover);
            // 
            // update_book
            // 
            this.update_book.FlatAppearance.BorderSize = 0;
            this.update_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.update_book.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.update_book.ForeColor = System.Drawing.Color.White;
            this.update_book.Image = ((System.Drawing.Image)(resources.GetObject("update_book.Image")));
            this.update_book.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.update_book.Location = new System.Drawing.Point(3, 300);
            this.update_book.Name = "update_book";
            this.update_book.Size = new System.Drawing.Size(188, 58);
            this.update_book.TabIndex = 4;
            this.update_book.Text = "Update Book";
            this.update_book.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.update_book.UseVisualStyleBackColor = true;
            this.update_book.Click += new System.EventHandler(this.update_book_Click);
            this.update_book.MouseHover += new System.EventHandler(this.update_mouse_hover);
            this.update_book.MouseMove += new System.Windows.Forms.MouseEventHandler(this.update_leave_hover);
            // 
            // view_books
            // 
            this.view_books.FlatAppearance.BorderSize = 0;
            this.view_books.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.view_books.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.view_books.ForeColor = System.Drawing.Color.White;
            this.view_books.Image = ((System.Drawing.Image)(resources.GetObject("view_books.Image")));
            this.view_books.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.view_books.Location = new System.Drawing.Point(3, 235);
            this.view_books.Name = "view_books";
            this.view_books.Size = new System.Drawing.Size(188, 58);
            this.view_books.TabIndex = 3;
            this.view_books.Text = "View Books";
            this.view_books.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.view_books.UseVisualStyleBackColor = true;
            this.view_books.Click += new System.EventHandler(this.view_books_Click);
            this.view_books.MouseLeave += new System.EventHandler(this.view_mouse_leave);
            this.view_books.MouseHover += new System.EventHandler(this.view_mouse_hover);
            // 
            // add_book
            // 
            this.add_book.BackColor = System.Drawing.Color.Transparent;
            this.add_book.FlatAppearance.BorderSize = 0;
            this.add_book.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_book.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.add_book.ForeColor = System.Drawing.Color.White;
            this.add_book.Image = ((System.Drawing.Image)(resources.GetObject("add_book.Image")));
            this.add_book.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.add_book.Location = new System.Drawing.Point(3, 171);
            this.add_book.Name = "add_book";
            this.add_book.Size = new System.Drawing.Size(188, 58);
            this.add_book.TabIndex = 2;
            this.add_book.Text = "Add Book";
            this.add_book.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.add_book.UseVisualStyleBackColor = false;
            this.add_book.Click += new System.EventHandler(this.add_book_Click);
            this.add_book.MouseLeave += new System.EventHandler(this.add_book_mouse_leave);
            this.add_book.MouseHover += new System.EventHandler(this.add_book_hover);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(32, 6);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(128, 131);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // button1
            // 
            this.button1.Image = ((System.Drawing.Image)(resources.GetObject("button1.Image")));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(203, 62);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(500, 36);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // search_btn
            // 
            this.search_btn.Font = new System.Drawing.Font("Yu Gothic UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.search_btn.Location = new System.Drawing.Point(708, 62);
            this.search_btn.Name = "search_btn";
            this.search_btn.Size = new System.Drawing.Size(84, 35);
            this.search_btn.TabIndex = 4;
            this.search_btn.Text = "Search";
            this.search_btn.UseVisualStyleBackColor = true;
            // 
            // search_book
            // 
            this.search_book.BackColor = System.Drawing.SystemColors.Info;
            this.search_book.Location = new System.Drawing.Point(241, 70);
            this.search_book.Name = "search_book";
            this.search_book.PlaceholderText = "Search here";
            this.search_book.Size = new System.Drawing.Size(441, 23);
            this.search_book.TabIndex = 5;
            // 
            // tabs
            // 
            this.tabs.Controls.Add(this.view_page);
            this.tabs.Controls.Add(this.add_page);
            this.tabs.Location = new System.Drawing.Point(229, 126);
            this.tabs.Name = "tabs";
            this.tabs.Size = new System.Drawing.Size(541, 383);
            this.tabs.TabIndex = 6;
            this.tabs.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // view_page
            // 
            this.view_page.BackColor = System.Drawing.Color.LightGray;
            this.view_page.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.view_page.Location = new System.Drawing.Point(-3, 0);
            this.view_page.Name = "view_page";
            this.view_page.Size = new System.Drawing.Size(541, 383);
            this.view_page.TabIndex = 1;
            this.view_page.Load += new System.EventHandler(this.view_page_Load);
            // 
            // add_page
            // 
            this.add_page.BackColor = System.Drawing.Color.LightGray;
            this.add_page.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.add_page.Location = new System.Drawing.Point(-3, 0);
            this.add_page.Name = "add_page";
            this.add_page.Size = new System.Drawing.Size(541, 383);
            this.add_page.TabIndex = 0;
            // 
            // dashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(814, 544);
            this.Controls.Add(this.tabs);
            this.Controls.Add(this.search_book);
            this.Controls.Add(this.search_btn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "dashboard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.dashboard_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tabs.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Panel panel1;
        private PictureBox pictureBox1;
        private Panel panel2;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label1;
        private PictureBox pictureBox3;
        private Button delete_book;
        private Button update_book;
        private Button view_books;
        private Button add_book;
        private Label label3;
        private Button button1;
        private Button search_btn;
        private TextBox search_book;
        private Panel tabs;
        private UC_Addbook add_page;
        private viewBooks view_page;
    }
}