﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace LMS
{
    public partial class viewBooks : UserControl
    {
        DataGridView table = new DataGridView();
        public viewBooks()
        {
            InitializeComponent();
        }
        
        private void close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dataTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void viewBooks_Load(object sender, EventArgs e)
        {

            dataGridView1.ColumnHeadersDefaultCellStyle.BackColor  = Color.Tomato;
            dataGridView1.Columns[0].DefaultCellStyle.BackColor = Color.Salmon;
            dataGridView1.Columns[1].DefaultCellStyle.BackColor = Color.Salmon;
            dataGridView1.Columns[2].DefaultCellStyle.BackColor = Color.Salmon;
            dataGridView1.Columns[3].DefaultCellStyle.BackColor = Color.Salmon;
            dataGridView1.Columns[4].DefaultCellStyle.BackColor = Color.Salmon;


            StreamReader file = new StreamReader("books.txt");

            string str1,str2,str3, str4,str5;
            while (!file.EndOfStream)
            {
              
                str1= file.ReadLine();
                str2= file.ReadLine();
                str3= file.ReadLine();
                str4= file.ReadLine();
                str5 = file.ReadLine();
                dataGridView1.Rows.Add(str1,str2,str3,str4,str5);

            }
            file.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void close_view_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
