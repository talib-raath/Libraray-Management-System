﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using LMS;

namespace LMS
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
            add_page.Hide();

        }


        //Adding user controls
        private void UserControlAdd_book(UserControl addBooks)
        {
            addBooks.Dock = DockStyle.Fill;
            tabs.Controls.Clear();
            tabs.Controls.Add(addBooks);
            addBooks.BringToFront();
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void add_book_hover(object sender, EventArgs e)
        {
            add_book.BackColor = Color.DarkGray;
        }

        private void add_book_mouse_leave(object sender, EventArgs e)
        {
            add_book.BackColor = Color.Transparent;

        }

        private void view_mouse_hover(object sender, EventArgs e)
        {
            view_books.BackColor = Color.DarkGray;

        }

        private void view_mouse_leave(object sender, EventArgs e)
        {
            view_books.BackColor = Color.Transparent;

        }

        private void update_mouse_hover(object sender, EventArgs e)
        {
            update_book.BackColor = Color.DarkGray;  
        }

        private void update_leave_hover(object sender, MouseEventArgs e)
        {
            update_book.BackColor = Color.Transparent;

        }

        private void delete_mouse_hover(object sender, EventArgs e)
        {
            delete_book.BackColor = Color.DarkGray;

        }

        private void delete_mouse_keave_hover(object sender, EventArgs e)
        {
            delete_book.BackColor = Color.Transparent;

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void add_book_Click(object sender, EventArgs e)
        {
            
            view_page.Hide();
            add_page.Show();
        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void add_page_Load(object sender, EventArgs e)
        {
            add_page.Hide();


        }

        private void view_books_Click(object sender, EventArgs e)
        {
            add_page.Hide();
            view_page.Show();

        }

        private void update_book_Click(object sender, EventArgs e)
        {
            
        }

        private void view_page_Load(object sender, EventArgs e)
        {
            view_page.Hide();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
        }
    }
}
