﻿namespace LMS
{
    partial class UC_Addbook
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UC_Addbook));
            this.label1 = new System.Windows.Forms.Label();
            this.isbn = new System.Windows.Forms.TextBox();
            this.Book_name = new System.Windows.Forms.TextBox();
            this.author_name = new System.Windows.Forms.TextBox();
            this.copies = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.close_view = new System.Windows.Forms.PictureBox();
            this.datepicker = new System.Windows.Forms.DateTimePicker();
            ((System.ComponentModel.ISupportInitialize)(this.close_view)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(179, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(169, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Enter Book Details";
            // 
            // isbn
            // 
            this.isbn.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.isbn.Location = new System.Drawing.Point(191, 65);
            this.isbn.Name = "isbn";
            this.isbn.PlaceholderText = "ISBN";
            this.isbn.Size = new System.Drawing.Size(136, 23);
            this.isbn.TabIndex = 1;
            // 
            // Book_name
            // 
            this.Book_name.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.Book_name.Location = new System.Drawing.Point(191, 94);
            this.Book_name.Name = "Book_name";
            this.Book_name.PlaceholderText = "Book Name";
            this.Book_name.Size = new System.Drawing.Size(136, 23);
            this.Book_name.TabIndex = 2;
            // 
            // author_name
            // 
            this.author_name.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.author_name.Location = new System.Drawing.Point(191, 123);
            this.author_name.Name = "author_name";
            this.author_name.PlaceholderText = "Author Name";
            this.author_name.Size = new System.Drawing.Size(136, 23);
            this.author_name.TabIndex = 3;
            this.author_name.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // copies
            // 
            this.copies.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.copies.Location = new System.Drawing.Point(191, 152);
            this.copies.Name = "copies";
            this.copies.PlaceholderText = "Copies";
            this.copies.Size = new System.Drawing.Size(136, 23);
            this.copies.TabIndex = 4;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Salmon;
            this.button1.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.Location = new System.Drawing.Point(213, 236);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 36);
            this.button1.TabIndex = 5;
            this.button1.Text = "Submit";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // close_view
            // 
            this.close_view.BackColor = System.Drawing.Color.Transparent;
            this.close_view.Image = ((System.Drawing.Image)(resources.GetObject("close_view.Image")));
            this.close_view.Location = new System.Drawing.Point(507, -2);
            this.close_view.Name = "close_view";
            this.close_view.Size = new System.Drawing.Size(32, 31);
            this.close_view.TabIndex = 6;
            this.close_view.TabStop = false;
            this.close_view.Click += new System.EventHandler(this.close_view_Click);
            // 
            // datepicker
            // 
            this.datepicker.CalendarMonthBackground = System.Drawing.SystemColors.InactiveCaption;
            this.datepicker.CalendarTitleBackColor = System.Drawing.SystemColors.AppWorkspace;
            this.datepicker.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.datepicker.Location = new System.Drawing.Point(191, 197);
            this.datepicker.Name = "datepicker";
            this.datepicker.Size = new System.Drawing.Size(136, 23);
            this.datepicker.TabIndex = 7;
            this.datepicker.Tag = "";
            this.datepicker.Value = new System.DateTime(2023, 2, 11, 18, 53, 15, 0);
            // 
            // UC_Addbook
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightGray;
            this.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.Controls.Add(this.datepicker);
            this.Controls.Add(this.close_view);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.copies);
            this.Controls.Add(this.author_name);
            this.Controls.Add(this.Book_name);
            this.Controls.Add(this.isbn);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Name = "UC_Addbook";
            this.Size = new System.Drawing.Size(537, 379);
            ((System.ComponentModel.ISupportInitialize)(this.close_view)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label label1;
        private TextBox isbn;
        private TextBox Book_name;
        private TextBox author_name;
        private TextBox copies;
        private Button button1;
        private PictureBox close_view;
        private DateTimePicker datepicker;
    }
}
