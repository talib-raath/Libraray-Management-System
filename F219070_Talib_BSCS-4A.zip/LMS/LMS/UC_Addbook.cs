﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LMS
{
    public partial class UC_Addbook : UserControl
    {
        public UC_Addbook()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();

            StreamWriter file = new StreamWriter("books.txt", true);

            file.Write(isbn.Text);
            file.Write("\n");
            file.Write(Book_name.Text);
            file.Write("\n");
            file.Write(author_name.Text);
            file.Write("\n");
            file.Write(copies.Text);
            file.Write("\n");
            file.Write(datepicker);
            file.Write("\n");
            datepicker = null;
            isbn.Text = null;
            author_name.Text = null;
            Book_name.Text = null;
            copies.Text = null;
            file.Close();
        }

        private void close_view_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }
    }
}
