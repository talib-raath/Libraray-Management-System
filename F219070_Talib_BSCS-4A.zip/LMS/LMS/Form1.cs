namespace LMS
{
    public partial class login : Form
    {
        public login()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void close_button_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void login_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click_1(object sender, EventArgs e)
        {

        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
          
            if (password.Text == "allah" && username.Text == "talib")
            {
                this.Hide();
                dashboard dash = new dashboard();
                MessageBox.Show("Login Successfully!");
                dash.ShowDialog();
            }
            else
            {
                MessageBox.Show("Wrong Credentials!");
            }

        }
    }
}